#define START_ID 1401001

struct student{
    int id;
    char name[20];
    int score;
    int grade;
};
