#ifndef BUSINESS_H
#define BUSINESS_H

typedef struct business
{
	char name[20];
	char work_up[20];
	char work_name[20];
	int phone;
